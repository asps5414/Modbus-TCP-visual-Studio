﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Runtime.InteropServices.ComTypes;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAAA
{
    public partial class Form1 : Form
    {
        private int transactionId = 1; // 初始化 Transaction Identifier
        private bool isReceiving = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSendRequest_Click(object sender, EventArgs e)
        {
            if (!isReceiving)
            {
                isReceiving = true;
                btnSendRequest.Text = "Pause";
                Task.Run(() => SendRequest(true));
            }
            else
            {
                isReceiving = false;
                btnSendRequest.Text = "Start";
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
                Task.Run(() => SendRequest(false));
         

        }

        private void SendRequest(bool continuous)
        {
            try
            {
                Int32 port = 502; // Modbus TCP 預設埠
                using (TcpClient client = new TcpClient("127.0.0.1", port))
                {
                    do
                    {
                        Byte[] transactionIdBytes = BitConverter.GetBytes((short)transactionId);
                        transactionId++;
                        Array.Reverse(transactionIdBytes); // 大端序需要反轉字節順序

                        Byte[] data = new Byte[]
                        {
                              transactionIdBytes[0], transactionIdBytes[1], // Transaction Identifier
                            0x00, 0x00, // Protocol Identifier
                            0x00, 0x06, // Length
                            0x01,       // Unit Identifier
                            0x04,       // Function Code
                            0x0B, 0xBD, // Starting Address
                            0x00, 0x08  // Quantity of Registers
                           };


                        NetworkStream stream = client.GetStream();

                        stream.Write(data, 0, data.Length);
                        Log("Sent: " + BitConverter.ToString(data));

                        data = new Byte[256];
                        Int32 bytes = stream.Read(data, 0, data.Length);

                        // 顯示接收到的字節數據
                        Log("Received: " + BitConverter.ToString(data, 0, bytes));

                        if (bytes >= 22)
                        {
                            // 解析回應中的 CPU 和 RAM 使用率
                            float cpuUsage = BitConverter.ToSingle(data, 9);
                            float availableMemory = BitConverter.ToSingle(data, 13);
                            float totalMemory = BitConverter.ToSingle(data, 17);
                            float usedMemory = BitConverter.ToSingle(data, 21);

                            Log($"CPU Usage: {cpuUsage:F2}%");
                            Log($"Available Memory: {availableMemory:F2} MB");
                            Log($"Total Memory: {totalMemory:F2} MB");
                            Log($"Used Memory: {usedMemory:F2} MB \n");
                            Log($"<-------------"+transactionIdBytes[1]+"------------------> \n");

                            // 計算已使用記憶體的百分比
                            float memoryUsagePercentage = (usedMemory / totalMemory) * 100;

                            // 更新 UI 的值
                            UpdateUI(cpuUsage, memoryUsagePercentage);
                        }

                        // 等待一段時間後再次請求數據（如果是連續請求）
                        if (continuous)
                        {
                            Task.Delay(1000).Wait(); // 1 秒
                        }

                    } while (continuous && isReceiving) ;
                }
            }
            catch (ArgumentNullException ex)
            {
                Log("ArgumentNullException: " + ex.ToString());
            }
            catch (SocketException ex)
            {
                Log("SocketException: " + ex.ToString());
            }
            catch (IOException ex)
            {
                Log("IOException: " + ex.ToString());
            }
        }

        private void UpdateUI(float cpuUsage, float memoryUsagePercentage)
        {
            // 更新 label3 和 progressBar1
            BeginInvoke(new Action(() =>
            {
                label3.Text = $"CPU Usage: {cpuUsage:F2}%";
                progressBar1.Value = (int)Math.Round(cpuUsage);
            }));

            // 更新 label4 和 progressBar2
            BeginInvoke(new Action(() =>
            {
                label4.Text = $"Memory Usage: {memoryUsagePercentage:F2}%";
                progressBar2.Value = (int)Math.Round(memoryUsagePercentage);
            }));
        }

        private void Log(string message)
        {
            BeginInvoke(new Action(() =>
            {
                txtLog.AppendText(message + Environment.NewLine);
            }));
        }
        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }
    }
}
