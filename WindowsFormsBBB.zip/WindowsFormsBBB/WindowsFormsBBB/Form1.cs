﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.Devices;

namespace WindowsFormsBBB
{
    public partial class Form1 : Form
    {
        private TcpListener server = null;
        private Thread serverThread = null;
        private PerformanceCounter cpuCounter;
        private PerformanceCounter ramCounter;

        public Form1()
        {
            InitializeComponent();

            cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            ramCounter = new PerformanceCounter("Memory", "Available MBytes");

            // 啟動計時器以定期更新 CPU 和 RAM 使用率
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000; // 每秒更新一次
            timer.Tick += new EventHandler(UpdatePerformanceCounters);
            timer.Start();
        }

        private void btnStartServer_Click(object sender, EventArgs e)
        {
            if (serverThread == null)
            {
                serverThread = new Thread(StartServer);
                serverThread.IsBackground = true;
                serverThread.Start();
                Log("Server started...");
            }
        }

        private void StartServer()
        {
            try
            {
                Int32 port = 502; // Modbus TCP 預設埠
                IPAddress localAddr = IPAddress.Parse("127.0.0.1");

                server = new TcpListener(localAddr, port);
                server.Start();

                Byte[] bytes = new Byte[256];

                while (true)
                {
                    TcpClient client = server.AcceptTcpClient();
                    NetworkStream stream = client.GetStream();

                    try
                    {
                        int i;
                        while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
                        {
                            // 直接處理字節數組，不轉換為字符串
                            byte[] receivedData = new byte[i];
                            Array.Copy(bytes, 0, receivedData, 0, i);
                            Log("Received: " + BitConverter.ToString(receivedData));

                            // 讀取當前的 CPU 和 RAM 使用率
                            float cpuUsage = cpuCounter.NextValue();
                            float availableMemory = ramCounter.NextValue();
                            float totalMemory = GetTotalMemoryInMB();
                            float usedMemory = totalMemory - availableMemory;

                            // 將 CPU 使用率格式化為小數點前三位和小數點後兩位
                            float formattedCpuUsage = (float)Math.Round(cpuUsage, 2);

                            byte[] cpuUsageBytes = BitConverter.GetBytes(formattedCpuUsage);
                            byte[] availableMemoryBytes = BitConverter.GetBytes(availableMemory);
                            byte[] totalMemoryBytes = BitConverter.GetBytes(totalMemory);
                            byte[] usedMemoryBytes = BitConverter.GetBytes(usedMemory);

                            // 構造回應封包
                            int totalLength = 9 + cpuUsageBytes.Length + availableMemoryBytes.Length + totalMemoryBytes.Length + usedMemoryBytes.Length;
                            byte[] response = new byte[totalLength];

                            // 複製請求中的 Transaction Identifier, Protocol Identifier, Length, Unit Identifier, Function Code
                            Array.Copy(receivedData, 0, response, 0, 8);

                            // 設置 Byte Count
                            response[8] = (byte)(cpuUsageBytes.Length + availableMemoryBytes.Length + totalMemoryBytes.Length + usedMemoryBytes.Length);
                            response[5] = (byte)(cpuUsageBytes.Length + availableMemoryBytes.Length + totalMemoryBytes.Length + usedMemoryBytes.Length + 3);

                            // 複製數據到回應封包
                            Array.Copy(cpuUsageBytes, 0, response, 9, cpuUsageBytes.Length);
                            Array.Copy(availableMemoryBytes, 0, response, 9 + cpuUsageBytes.Length, availableMemoryBytes.Length);
                            Array.Copy(totalMemoryBytes, 0, response, 9 + cpuUsageBytes.Length + availableMemoryBytes.Length, totalMemoryBytes.Length);
                            Array.Copy(usedMemoryBytes, 0, response, 9 + cpuUsageBytes.Length + availableMemoryBytes.Length + totalMemoryBytes.Length, usedMemoryBytes.Length);

                            response[8] = (byte)(cpuUsageBytes.Length + availableMemoryBytes.Length + totalMemoryBytes.Length + usedMemoryBytes.Length);                          

                            response[5] = (byte)(response[8] + 3);

                            stream.Write(response, 0, response.Length);
                            stream.Flush();
                            for (int j = 0; j < response.Length; j++)
                            {
                                Log($"response[{j}]: {response[j]}");
                            }

                            Log("Sent: " + BitConverter.ToString(response));
                        }
                    }
                    catch (IOException ioEx)
                    {
                        Log("IOException: " + ioEx.Message);
                    }
                    finally
                    {
                        client.Close();
                    }
                }
            }
            catch (SocketException e)
            {
                Log("SocketException: " + e.ToString());
            }
            finally
            {
                server.Stop();
            }
        }

        private void UpdatePerformanceCounters(object sender, EventArgs e)
        {
            float cpuUsage = cpuCounter.NextValue();
            float availableMemory = ramCounter.NextValue();
            float totalMemory = GetTotalMemoryInMB();
            float usedMemory = totalMemory - availableMemory;

            string message = string.Format("CPU Usage: {0:0.0}%\r\nUsed Memory: {1:0.0} MB\r\nTotal Memory: {2:0.0} MB\r\nAvailable Memory: {3:0.0} MB",
                                           cpuUsage, usedMemory, totalMemory, availableMemory);

            if (textBox1.InvokeRequired)
            {
                textBox1.Invoke(new MethodInvoker(delegate
                {
                    textBox1.Text = message;
                }));
            }
            else
            {
                textBox1.Text = message;
            }
        }

        // 獲取總物理記憶體大小
        private float GetTotalMemoryInMB()
        {
            ComputerInfo ci = new ComputerInfo();
            ulong totalMemory = ci.TotalPhysicalMemory;
            return totalMemory / (1024 * 1024); // 將字節轉換為 MB
        }

        private void Log(string message)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new MethodInvoker(delegate
                {
                    txtLog.AppendText(message + Environment.NewLine);
                }));
            }
            else
            {
                txtLog.AppendText(message + Environment.NewLine);
            }
        }
    }
}
